'use strict';

angular.module('myApp.admin', ['ngRoute'])

    .config(['$routeProvider', function($routeProvider) {
        $routeProvider.when('/admin', {
            templateUrl: 'admin/admin.html',
            controller: 'AdminCtrl'
        });
    }])


.controller('AdminCtrl', function($scope, $http, $location) {
    $http.get("http://localhost:8081")
        .then(function(response) {
            $scope.project = response.data;

            $scope.url = document.URL;
            // console.log($scope.url);

            $scope.id = $scope.url.substring($scope.url.lastIndexOf('?')+1);
            // console.log($scope.id);

        });


});