'use strict';

angular.module('myApp.meat', ['ngRoute'])

    .config(['$routeProvider', function($routeProvider) {
        $routeProvider

            .when('/meat', {
                templateUrl: 'meat/meat.html',
                controller: 'MeatCtrl'
            })
            .otherwise({
                redirectTo: '/reception'
            });
    }])
    .controller('MeatCtrl', ['$scope','$http','service',function($scope,$http, service) {
        service.func("https://raw.githubusercontent.com/LearnWebCode/json-example/master/animals-1.json")
            .then(res => {
                console.log('res in ctrl', res.data)
            })
    }])
    .controller('MeatCtrl', function ($scope, $http) {
        $http.get("http://localhost:8081")
            .then(function (response) {
                $scope.project = response.data;
                $scope.receptionOnPage = 5;
                $scope.startFrom = 0;
                $scope.count = 0;
                $scope.CountPageDivs = [];
                for (var i = 1; i <= Math.round($scope.project.data.meat.length / 5); i++) {
                    $scope.CountPageDivs.push(i);
                }
                $scope.PaginationFunction = function (event) {
                    $scope.turId = event.target.id;
                    $scope.startFrom = ($scope.turId - 1) * $scope.receptionOnPage;
                };
                $scope.addToCart = function (a) {
                    $scope.count = a + 1;
                };
            });
    })