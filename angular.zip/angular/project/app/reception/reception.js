'use strict';

angular.module('myApp.reception', ['ngRoute'])

    .config(['$routeProvider', function($routeProvider) {
        $routeProvider.when('/reception', {
            templateUrl: 'reception/reception.html',
            controller: 'ReceptionCtrl'
        });
    }])

    .controller('ReceptionCtrl', function($scope, $http, $location) {
        $http.get("http://localhost:8081")
            .then(function(response) {
                $scope.project = response.data;

                $scope.url = document.URL;
                // console.log($scope.url);

                $scope.id = $scope.url.substring($scope.url.lastIndexOf('?')+1);
                 console.log($scope.id);

            });

    });