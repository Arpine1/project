'use strict';

angular.module('myApp.child', ['ngRoute'])

    .config(['$routeProvider', function($routeProvider) {
        $routeProvider

            .when('/child', {
                templateUrl: 'child/child.html',
                controller: 'ChildCtrl'
            })
            .otherwise({
                redirectTo: '/reception'
            });
    }])
    .controller('ChildCtrl', function ($scope, $http) {
        $http.get("http://localhost:8081")
            .then(function (response) {
                $scope.project = response.data;
                $scope.receptionOnPage = 5;
                $scope.startFrom = 0;
                $scope.count = 0;
                $scope.CountPageDivs = [];
                for (var i = 1; i <= Math.round($scope.project.data.child.length / 5); i++) {
                    $scope.CountPageDivs.push(i);
                }
                $scope.PaginationFunction = function (event) {
                    $scope.turId = event.target.id;
                    $scope.startFrom = ($scope.turId - 1) * $scope.receptionOnPage;
                };
                $scope.addToCart = function (a) {
                    $scope.count = a + 1;
                };
            });
    })